import Link from "next/link";
import { BrandMark } from "../BrandMark";

const nav = [
  { href: "/admin", label: "لوحة التحكم" },
  { href: "/admin/products", label: "المنتجات" },
  { href: "/admin/categories", label: "الأقسام" },
  { href: "/admin/orders", label: "الطلبات" },
  { href: "/admin/settings", label: "الإعدادات" }
];

export function AdminShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-paper" dir="rtl" lang="ar">
      <aside className="border-b border-ink/10 bg-ink text-bone lg:fixed lg:inset-y-0 lg:right-0 lg:w-72 lg:border-b-0">
        <div className="p-5">
          <BrandMark />
          <p className="mt-4 text-sm leading-6 text-bone/55">إدارة وايت هاوس، منتجات وأقسام وطلبات بإيقاع عملي واضح.</p>
        </div>
        <nav className="flex gap-2 overflow-x-auto px-4 pb-4 lg:grid lg:px-5">
          {nav.map((item) => (
            <Link key={item.href} href={item.href} className="whitespace-nowrap border border-bone/10 px-4 py-3 text-sm font-black">
              {item.label}
            </Link>
          ))}
          <form action="/api/admin/logout" method="post">
            <button className="whitespace-nowrap border border-bone/10 px-4 py-3 text-sm font-black">تسجيل الخروج</button>
          </form>
        </nav>
      </aside>
      <main className="p-5 lg:mr-72 lg:p-9">{children}</main>
    </div>
  );
}

export function AdminHeader({ title, action }: { title: string; action?: React.ReactNode }) {
  return (
    <div className="mb-8 flex flex-wrap items-end justify-between gap-4 border-b border-ink/10 pb-6">
      <div>
        <p className="text-sm font-black uppercase text-caramel">White House Admin</p>
        <h1 className="mt-2 text-4xl font-black">{title}</h1>
      </div>
      {action}
    </div>
  );
}
