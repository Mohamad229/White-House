"use client";

import { useState } from "react";
import type { CategoryView } from "@/lib/types";

export function CategoryForm({ category }: { category?: CategoryView | null }) {
  const [status, setStatus] = useState("");

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setStatus("");
    const form = new FormData(event.currentTarget);
    const body = Object.fromEntries(form.entries());
    const response = await fetch(category ? `/api/admin/categories/${category.id}` : "/api/admin/categories", {
      method: category ? "PUT" : "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...body, isVisible: form.get("isVisible") === "on", sortOrder: Number(body.sortOrder || 0) })
    });
    setStatus(response.ok ? "تم الحفظ." : "تعذر الحفظ. تأكد من قاعدة البيانات.");
  }

  return (
    <form onSubmit={submit} className="grid gap-4 bg-bone p-5">
      <div className="grid gap-4 md:grid-cols-2">
        <Field name="nameAr" label="الاسم العربي" defaultValue={category?.nameAr} />
        <Field name="nameEn" label="الاسم الإنجليزي" defaultValue={category?.nameEn} />
        <Field name="slug" label="الرابط المختصر" defaultValue={category?.slug} />
        <Field name="imageUrl" label="رابط الصورة" defaultValue={category?.imageUrl || "/brand/shirt-stone.png"} />
        <Field name="sortOrder" label="الترتيب" type="number" defaultValue={String(category?.sortOrder ?? 0)} />
      </div>
      <Textarea name="descriptionAr" label="الوصف العربي" defaultValue={category?.descriptionAr} />
      <Textarea name="descriptionEn" label="الوصف الإنجليزي" defaultValue={category?.descriptionEn} />
      <label className="flex items-center gap-2 font-black">
        <input type="checkbox" name="isVisible" defaultChecked={category?.isVisible ?? true} />
        ظاهر في المتجر
      </label>
      <button className="w-fit bg-ink px-6 py-3 font-black text-bone">حفظ القسم</button>
      {status && <p className="font-bold text-caramel">{status}</p>}
    </form>
  );
}

function Field({ label, ...props }: React.InputHTMLAttributes<HTMLInputElement> & { label: string }) {
  return (
    <label className="block">
      <span className="mb-2 block text-sm font-black">{label}</span>
      <input className="admin-field" {...props} />
    </label>
  );
}

function Textarea({ label, ...props }: React.TextareaHTMLAttributes<HTMLTextAreaElement> & { label: string }) {
  return (
    <label className="block">
      <span className="mb-2 block text-sm font-black">{label}</span>
      <textarea className="admin-field min-h-24" {...props} />
    </label>
  );
}
