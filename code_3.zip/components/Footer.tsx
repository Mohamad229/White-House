import Link from "next/link";
import { BrandMark } from "./BrandMark";
import { dictionary, localPath, textByLocale } from "@/lib/i18n";
import type { CategoryView, Locale, StoreSettingsView } from "@/lib/types";

export function Footer({
  locale,
  categories,
  settings
}: {
  locale: Locale;
  categories: CategoryView[];
  settings: StoreSettingsView;
}) {
  const t = dictionary[locale];
  const whatsappNumber = settings.whatsappNumber.replace(/[^\d]/g, "");
  const marqueeItems = Array.from({ length: 12 }, (_, index) => (
    <span key={index} className="px-5">
      {t.marquee}
    </span>
  ));

  return (
    <footer id="about" className="mt-16 overflow-hidden bg-ink text-bone">
      <div className="border-y border-bone/10 bg-caramel py-3 text-ink">
        <div
          className="flex w-max min-w-[200%] text-3xl font-black uppercase tracking-normal md:text-5xl"
          style={{ animation: `${locale === "ar" ? "marquee-rtl" : "marquee-ltr"} 28s linear infinite` }}
          aria-hidden
        >
          <div className="flex min-w-[50%]">{marqueeItems}</div>
          <div className="flex min-w-[50%]">{marqueeItems}</div>
        </div>
      </div>

      <div className="grid gap-10 px-4 py-12 sm:px-6 md:px-10 lg:grid-cols-[1.05fr_1.5fr] lg:px-16 lg:py-16 xl:px-20">
        <div className="max-w-xl">
          <BrandMark inverse />
          <p className="mt-7 text-2xl font-semibold leading-tight md:text-4xl">
            {textByLocale(locale, settings.aboutAr, settings.aboutEn)}
          </p>
          <p className="mt-5 max-w-lg leading-8 text-bone/65">
            {textByLocale(locale, settings.locationAr, settings.locationEn)}
          </p>
        </div>

        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
          <FooterColumn title={t.usefulLinks}>
            <Link href={localPath(locale, "/")}>{t.home}</Link>
            <Link href={localPath(locale, "/#categories")}>{t.categories}</Link>
            <Link href={localPath(locale, "/products")}>{t.products}</Link>
            <Link href={localPath(locale, "/#about")}>{t.about}</Link>
          </FooterColumn>

          <FooterColumn title={t.categories}>
            {categories.map((category) => (
              <Link key={category.id} href={localPath(locale, `/products?category=${category.slug}`)}>
                {textByLocale(locale, category.nameAr, category.nameEn)}
              </Link>
            ))}
          </FooterColumn>

          <FooterColumn title={t.contact}>
            <a href={`mailto:${settings.supportEmail}`}>{settings.supportEmail}</a>
            {whatsappNumber && <a href={`https://wa.me/${whatsappNumber}`}>WhatsApp</a>}
            {settings.supportPhone && <a href={`tel:${settings.supportPhone}`}>{settings.supportPhone}</a>}
            {settings.facebookUrl && <a href={settings.facebookUrl}>Facebook</a>}
            {settings.instagramUrl && <a href={settings.instagramUrl}>Instagram</a>}
          </FooterColumn>
        </div>
      </div>

      <div className="border-t border-bone/10 px-4 py-5 text-sm text-bone/55 sm:px-6 md:px-10 lg:px-16 xl:px-20">
        <span>White House Store</span>
      </div>
    </footer>
  );
}

function FooterColumn({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <h3 className="mb-5 text-sm font-black uppercase text-brass">{title}</h3>
      <div className="grid gap-3 text-base leading-7 text-bone/65 [&_a:hover]:text-brass">{children}</div>
    </div>
  );
}
