import Link from "next/link";
import { BrandMark } from "../BrandMark";

const nav = [
  { href: "/admin", label: "لوحة التحكم" },
  { href: "/admin/products", label: "المنتجات" },
  { href: "/admin/categories", label: "الأقسام" },
  { href: "/admin/orders", label: "الطلبات" },
  { href: "/admin/settings", label: "الإعدادات" }
];

export function AdminShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-bone" dir="rtl" lang="ar">
      <aside className="sticky top-0 z-40 border-b border-ink/10 bg-ink text-bone shadow-[0_20px_60px_rgb(23_22_60/0.18)] lg:fixed lg:inset-y-0 lg:right-0 lg:w-72 lg:border-b-0">
        <div className="flex items-center justify-between gap-4 p-4 lg:block lg:p-6">
          <BrandMark inverse />
          <p className="hidden lg:mt-5 lg:block lg:text-sm lg:leading-7 lg:text-bone/60">
            إدارة وايت هاوس: منتجات، أقسام، طلبات، وإعدادات بواجهة بسيطة لفريق المتجر.
          </p>
        </div>
        <nav className="flex gap-2 overflow-x-auto px-4 pb-4 lg:grid lg:px-5">
          {nav.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="tap-target min-w-max rounded-full border border-bone/10 px-4 py-3 text-sm font-black transition hover:border-brass hover:text-brass lg:rounded-2xl"
            >
              {item.label}
            </Link>
          ))}
          <form action="/api/admin/logout" method="post">
            <button className="tap-target min-w-max rounded-full border border-bone/10 px-4 py-3 text-sm font-black transition hover:border-brass hover:text-brass lg:rounded-2xl">
              تسجيل الخروج
            </button>
          </form>
        </nav>
      </aside>
      <main className="min-w-0 p-4 sm:p-5 lg:mr-72 lg:p-8 xl:p-10">{children}</main>
    </div>
  );
}

export function AdminHeader({ title, action }: { title: string; action?: React.ReactNode }) {
  return (
    <div className="mb-7 flex flex-col gap-4 border-b border-ink/10 pb-6 sm:flex-row sm:items-end sm:justify-between">
      <div>
        <p className="text-sm font-black uppercase tracking-[0.16em] text-caramel">White House Admin</p>
        <h1 className="mt-2 text-3xl font-black sm:text-4xl">{title}</h1>
      </div>
      {action}
    </div>
  );
}
