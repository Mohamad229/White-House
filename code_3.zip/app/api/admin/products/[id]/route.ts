import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { slugify } from "@/lib/format";

type ColorInput = {
  id?: string;
  nameAr: string;
  nameEn: string;
  hex: string;
  imageUrl?: string;
  isAvailable?: boolean;
  sortOrder?: number;
  sizes?: string[];
};

type ImageInput = {
  url: string;
  altAr?: string;
  altEn?: string;
  isMain?: boolean;
  colorId?: string;
  sortOrder?: number;
};

function parseJson<T>(value: unknown, fallback: T): T {
  try {
    return JSON.parse(String(value || "")) as T;
  } catch {
    return fallback;
  }
}

function arrayInput<T>(value: unknown, jsonValue: unknown, fallback: T[]): T[] {
  if (Array.isArray(value)) return value as T[];
  return parseJson<T[]>(jsonValue, fallback);
}

async function uniqueProductSlug(rawSlug: string, fallbackName: string, currentId: string) {
  const base = slugify(rawSlug || fallbackName || "product") || `product-${Date.now()}`;
  let candidate = base;
  let index = 2;
  while (true) {
    const existing = await prisma.product.findUnique({ where: { slug: candidate }, select: { id: true } });
    if (!existing || existing.id === currentId) return candidate;
    candidate = `${base}-${index}`;
    index += 1;
  }
}

export async function PUT(request: Request, { params }: { params: Promise<{ id: string }> }) {
  await requireAdmin();
  const { id } = await params;
  const body = await request.json();
  const images = arrayInput<ImageInput>(body.images, body.imagesJson, []);
  const colors = arrayInput<ColorInput>(body.colors, body.colorsJson, []);
  if (colors.length === 0) return NextResponse.json({ error: "Add at least one color." }, { status: 400 });
  const nameAr = String(body.nameAr || "").trim();
  const nameEn = String(body.nameEn || "").trim();
  const internalCode = String(body.internalCode || "").trim();
  const categoryId = String(body.categoryId || "").trim();
  if (!nameAr || !nameEn || !internalCode || !categoryId) {
    return NextResponse.json({ error: "Missing required product fields." }, { status: 400 });
  }

  await prisma.productImage.deleteMany({ where: { productId: id } });
  await prisma.productColor.deleteMany({ where: { productId: id } });

  const product = await prisma.product.update({
    where: { id },
    data: {
      categoryId,
      slug: await uniqueProductSlug(String(body.slug || ""), String(nameEn || nameAr || ""), id),
      internalCode,
      nameAr,
      nameEn,
      descriptionAr: String(body.descriptionAr || ""),
      descriptionEn: String(body.descriptionEn || ""),
      shortDescriptionAr: String(body.shortDescriptionAr || ""),
      shortDescriptionEn: String(body.shortDescriptionEn || ""),
      price: Number(body.price || 0),
      currency: "SYP",
      status: ["visible", "hidden", "outOfStock"].includes(String(body.status)) ? body.status as any : "visible",
      isFeatured: Boolean(body.isFeatured),
    }
  });

  const colorIdMap = new Map<string, string>();
  for (const color of colors) {
    const createdColor = await prisma.productColor.create({
      data: {
        productId: product.id,
        nameAr: String(color.nameAr || "").trim(),
        nameEn: String(color.nameEn || "").trim(),
        hex: String(color.hex || "#e5c582"),
        imageUrl: color.imageUrl || null,
        isAvailable: color.isAvailable !== false,
        sortOrder: Number(color.sortOrder || 0)
      }
    });
    if (color.id) colorIdMap.set(color.id, createdColor.id);
    colorIdMap.set(color.nameEn, createdColor.id);
    colorIdMap.set(color.nameAr, createdColor.id);
    if ((color.sizes || []).length > 0) {
      await prisma.productVariant.createMany({
        data: (color.sizes || []).map((size) => ({
          productId: product.id,
          colorId: createdColor.id,
          size,
          isAvailable: true
        }))
      });
    }
  }

  if (images.length > 0) {
    await prisma.productImage.createMany({
      data: images.map((image) => ({
        productId: product.id,
        url: image.url,
        altAr: image.altAr || body.nameAr,
        altEn: image.altEn || body.nameEn,
        isMain: Boolean(image.isMain),
        colorId: image.colorId ? (colorIdMap.get(image.colorId) || null) : null,
        sortOrder: Number(image.sortOrder || 0)
      }))
    });
  }

  return NextResponse.json(product);
}
