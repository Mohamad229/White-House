import Link from "next/link";
import { AdminHeader, AdminShell } from "@/components/admin/AdminShell";
import { LoginForm } from "@/components/admin/LoginForm";
import { getAdminSession } from "@/lib/auth";
import { getAdminSummary } from "@/lib/data";
import { formatMoney } from "@/lib/format";

export default async function Page() {
  const session = await getAdminSession();
  if (!session) {
    return (
      <div className="min-h-screen bg-paper p-5" dir="rtl" lang="ar">
        <LoginForm />
      </div>
    );
  }
  const summary = await getAdminSummary();
  return (
    <AdminShell>
      <AdminHeader title="لوحة التحكم" />
      <div className="grid gap-4 md:grid-cols-3">
        <Metric label="طلبات جديدة" value={summary.newOrders} />
        <Metric label="منتجات ظاهرة" value={summary.visibleProducts} />
        <Metric label="الأقسام" value={summary.categories} />
      </div>
      <div className="mt-8 grid gap-4 md:grid-cols-4">
        {[
          ["/admin/products/new", "إضافة منتج"],
          ["/admin/products", "إدارة المنتجات"],
          ["/admin/categories", "إدارة الأقسام"],
          ["/admin/orders", "متابعة الطلبات"]
        ].map(([href, label]) => (
          <Link key={href} href={href} className="bg-ink p-5 text-xl font-black text-bone">
            {label}
          </Link>
        ))}
      </div>
      <section className="mt-10 bg-bone p-5">
        <h2 className="mb-4 text-2xl font-black">آخر الطلبات</h2>
        <div className="grid gap-3">
          {summary.recentOrders.map((order: any) => (
            <Link key={order.id} href={`/admin/orders/${order.id}`} className="flex justify-between border-b border-ink/10 py-3">
              <span className="font-black">{order.code}</span>
              <span>{formatMoney(order.total, order.currency, "ar")}</span>
            </Link>
          ))}
          {summary.recentOrders.length === 0 && <p className="text-muted">لا توجد طلبات بعد.</p>}
        </div>
      </section>
    </AdminShell>
  );
}

function Metric({ label, value }: { label: string; value: number }) {
  return (
    <div className="bg-bone p-5">
      <p className="text-sm font-black text-caramel">{label}</p>
      <p className="mt-3 text-5xl font-black">{value}</p>
    </div>
  );
}
