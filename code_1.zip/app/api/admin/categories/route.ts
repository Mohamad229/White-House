import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function POST(request: Request) {
  await requireAdmin();
  const body = await request.json();
  const category = await prisma.category.create({
    data: {
      slug: String(body.slug),
      nameAr: String(body.nameAr),
      nameEn: String(body.nameEn),
      descriptionAr: String(body.descriptionAr || ""),
      descriptionEn: String(body.descriptionEn || ""),
      imageUrl: String(body.imageUrl || ""),
      isVisible: Boolean(body.isVisible),
      sortOrder: Number(body.sortOrder || 0)
    }
  });
  return NextResponse.json(category);
}
