"use client";

import { useCart } from "./CartProvider";

export function CartBadge() {
  const { count } = useCart();
  return (
    <button
      className="relative grid h-10 w-10 place-items-center bg-transparent text-lg"
      aria-label="Order items"
      type="button"
    >
      <span aria-hidden className="relative block h-5 w-5 border-b-2 border-l-2 border-ink before:absolute before:-right-1 before:-top-1 before:h-2 before:w-2 before:border-r-2 before:border-t-2 before:border-ink after:absolute after:-bottom-2 after:left-0 after:h-1 after:w-1 after:rounded-full after:bg-ink" />
      {count > 0 && (
        <span className="absolute -right-1 -top-1 grid h-5 min-w-5 place-items-center rounded-full bg-caramel px-1 text-[0.65rem] font-black text-bone">
          {count}
        </span>
      )}
    </button>
  );
}
