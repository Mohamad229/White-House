import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function PUT(request: Request, { params }: { params: Promise<{ id: string }> }) {
  await requireAdmin();
  const { id } = await params;
  const body = await request.json();
  const category = await prisma.category.update({
    where: { id },
    data: {
      slug: String(body.slug),
      nameAr: String(body.nameAr),
      nameEn: String(body.nameEn),
      descriptionAr: String(body.descriptionAr || ""),
      descriptionEn: String(body.descriptionEn || ""),
      imageUrl: String(body.imageUrl || ""),
      isVisible: Boolean(body.isVisible),
      sortOrder: Number(body.sortOrder || 0)
    }
  });
  return NextResponse.json(category);
}
