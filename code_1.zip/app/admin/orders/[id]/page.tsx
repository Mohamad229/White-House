import { notFound } from "next/navigation";
import { AdminHeader, AdminShell } from "@/components/admin/AdminShell";
import { requireAdmin } from "@/lib/auth";
import { getAdminOrder, getStoreSettings } from "@/lib/data";
import { formatMoney } from "@/lib/format";
import { buildWhatsAppUrl } from "@/lib/whatsapp";

export default async function Page({ params }: { params: Promise<{ id: string }> }) {
  await requireAdmin();
  const { id } = await params;
  const [order, settings] = await Promise.all([getAdminOrder(id), getStoreSettings()]);
  if (!order) notFound();
  const whatsappUrl = buildWhatsAppUrl(settings, order.locale as "ar" | "en", order as any);
  return (
    <AdminShell>
      <AdminHeader title={`طلب ${order.code}`} />
      <div className="grid gap-5 lg:grid-cols-[0.9fr_1.1fr]">
        <section className="bg-bone p-5">
          <h2 className="text-2xl font-black">بيانات العميل</h2>
          <div className="mt-4 grid gap-2 text-muted">
            <p>الاسم: {order.customerName}</p>
            <p>الهاتف: {order.customerPhone}</p>
            <p>المدينة والمنطقة: {order.cityArea}</p>
            <p>العنوان: {order.detailedAddress}</p>
            {order.notes && <p>ملاحظات: {order.notes}</p>}
          </div>
          <a className="mt-5 inline-block bg-ink px-5 py-3 font-black text-bone" href={whatsappUrl}>
            تواصل عبر واتساب
          </a>
          <form className="mt-5 flex gap-2" action={`/api/admin/orders/${order.id}`} method="post">
            <select className="admin-field" name="status" defaultValue={order.status}>
              <option value="new">new</option>
              <option value="contacted">contacted</option>
              <option value="completed">completed</option>
              <option value="cancelled">cancelled</option>
            </select>
            <button className="bg-caramel px-5 py-3 font-black text-bone">تحديث</button>
          </form>
        </section>
        <section className="bg-bone p-5">
          <h2 className="text-2xl font-black">المنتجات</h2>
          <div className="mt-4 grid gap-3">
            {order.items.map((item) => (
              <div key={item.id} className="border-b border-ink/10 pb-3">
                <h3 className="font-black">{item.selectedProductName}</h3>
                <p className="text-sm text-muted">
                  كود: {item.productInternalCode} | لون: {item.selectedColorName} | مقاس: {item.size} | كمية: {item.quantity}
                </p>
                <p className="mt-1 font-black">{formatMoney(item.lineTotal, item.currency, "ar")}</p>
              </div>
            ))}
          </div>
          <div className="mt-5 flex justify-between text-2xl font-black">
            <span>الإجمالي</span>
            <span>{formatMoney(order.total, order.currency, "ar")}</span>
          </div>
        </section>
      </div>
    </AdminShell>
  );
}
