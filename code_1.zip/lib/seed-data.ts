import type { CategoryView, ProductView, StoreSettingsView } from "./types";

export const seedSettings: StoreSettingsView = {
  id: "seed-settings",
  storeNameAr: "وايت هاوس",
  storeNameEn: "White House",
  whatsappNumber: "963900000000",
  supportPhone: "963900000000",
  supportEmail: "support@whitehouse.example",
  defaultCurrency: "SYP",
  facebookUrl: "https://facebook.com",
  whatsappUrl: "https://wa.me/963900000000",
  instagramUrl: "https://instagram.com",
  aboutAr:
    "وايت هاوس يقدم أساسيات رجالية يومية بقصات نظيفة، ألوان هادئة، وخامات تناسب حياة المدينة.",
  aboutEn:
    "White House edits everyday menswear into clean silhouettes, quiet colors, and city-ready essentials.",
  locationAr: "دمشق، سوريا. التوصيل والتفاصيل النهائية عبر واتساب.",
  locationEn: "Damascus, Syria. Delivery details are confirmed through WhatsApp."
};

export const seedCategories: CategoryView[] = [
  {
    id: "cat-tshirts",
    slug: "t-shirts",
    nameAr: "تي شيرت",
    nameEn: "T-Shirts",
    descriptionAr: "قطع يومية خفيفة بقصات مستقيمة وألوان أساسية.",
    descriptionEn: "Daily lightweight pieces with straight cuts and essential colors.",
    imageUrl: "https://images.unsplash.com/photo-1523398002811-999ca8dec234?auto=format&fit=crop&w=1200&q=82",
    isVisible: true,
    sortOrder: 1
  },
  {
    id: "cat-hoodies",
    slug: "hoodies",
    nameAr: "هوديز",
    nameEn: "Hoodies",
    descriptionAr: "طبقات دافئة بتفاصيل نظيفة وملمس فاخر.",
    descriptionEn: "Warm layers with clean details and a premium hand feel.",
    imageUrl: "https://images.unsplash.com/photo-1520975954732-35dd22299614?auto=format&fit=crop&w=1200&q=82",
    isVisible: true,
    sortOrder: 2
  },
  {
    id: "cat-jackets",
    slug: "jackets",
    nameAr: "جاكيت",
    nameEn: "Jackets",
    descriptionAr: "قطع خارجية عملية بلون داكن وحضور قوي.",
    descriptionEn: "Functional outerwear with dark tones and a strong profile.",
    imageUrl: "https://images.unsplash.com/photo-1551028719-00167b16eac5?auto=format&fit=crop&w=1200&q=82",
    isVisible: true,
    sortOrder: 3
  }
];

export const seedProducts: ProductView[] = [
  {
    id: "prod-stone-tee",
    categoryId: "cat-tshirts",
    slug: "stone-relaxed-tee",
    internalCode: "WH-TEE-001",
    nameAr: "تي شيرت ستون بقصة مريحة",
    nameEn: "Stone Relaxed Tee",
    descriptionAr:
      "تي شيرت قطني متوسط الوزن بقصة مريحة، مناسب للارتداء اليومي والطبقات الخفيفة.",
    descriptionEn:
      "A mid-weight cotton tee with a relaxed profile, made for daily wear and easy layering.",
    shortDescriptionAr: "قطن متوسط الوزن بقصة مريحة.",
    shortDescriptionEn: "Mid-weight cotton with a relaxed profile.",
    price: 185000,
    currency: "SYP",
    status: "visible",
    isFeatured: true,
    category: seedCategories[0],
    images: [
      {
        id: "img-stone",
        url: "https://images.unsplash.com/photo-1523398002811-999ca8dec234?auto=format&fit=crop&w=1200&q=82",
        altAr: "تي شيرت ستون",
        altEn: "Stone tee",
        isMain: true,
        colorId: "color-stone",
        sortOrder: 1
      },
      {
        id: "img-charcoal",
        url: "https://images.unsplash.com/photo-1506629905607-d405d7d3b0d2?auto=format&fit=crop&w=1200&q=82",
        altAr: "تي شيرت فحمي",
        altEn: "Charcoal tee",
        isMain: false,
        colorId: "color-charcoal",
        sortOrder: 2
      }
    ],
    colors: [
      {
        id: "color-stone",
        nameAr: "ستون",
        nameEn: "Stone",
        hex: "#eee9dd",
        imageUrl: "https://images.unsplash.com/photo-1523398002811-999ca8dec234?auto=format&fit=crop&w=1200&q=82",
        isAvailable: true,
        sortOrder: 1,
        variants: [
          { id: "v-stone-s", colorId: "color-stone", size: "S", isAvailable: true },
          { id: "v-stone-m", colorId: "color-stone", size: "M", isAvailable: true },
          { id: "v-stone-l", colorId: "color-stone", size: "L", isAvailable: true },
          { id: "v-stone-xl", colorId: "color-stone", size: "XL", isAvailable: true }
        ]
      },
      {
        id: "color-charcoal",
        nameAr: "فحمي",
        nameEn: "Charcoal",
        hex: "#282824",
        imageUrl: "https://images.unsplash.com/photo-1506629905607-d405d7d3b0d2?auto=format&fit=crop&w=1200&q=82",
        isAvailable: true,
        sortOrder: 2,
        variants: [
          { id: "v-char-m", colorId: "color-charcoal", size: "M", isAvailable: true },
          { id: "v-char-l", colorId: "color-charcoal", size: "L", isAvailable: true }
        ]
      }
    ]
  },
  {
    id: "prod-hoodie",
    categoryId: "cat-hoodies",
    slug: "cream-weight-hoodie",
    internalCode: "WH-HOD-014",
    nameAr: "هودي كريمي ثقيل",
    nameEn: "Cream Weight Hoodie",
    descriptionAr: "هودي ناعم بلون كريمي، جيب أمامي، وقصة متوازنة للشتاء الخفيف.",
    descriptionEn: "A soft cream hoodie with a front pocket and balanced fit for cooler days.",
    shortDescriptionAr: "هودي ناعم بلون كريمي فاخر.",
    shortDescriptionEn: "Soft cream hoodie with a premium finish.",
    price: 315000,
    currency: "SYP",
    status: "visible",
    isFeatured: true,
    category: seedCategories[1],
    images: [
      {
        id: "img-hoodie",
        url: "https://images.unsplash.com/photo-1520975954732-35dd22299614?auto=format&fit=crop&w=1200&q=82",
        altAr: "هودي كريمي",
        altEn: "Cream hoodie",
        isMain: true,
        colorId: "color-cream",
        sortOrder: 1
      }
    ],
    colors: [
      {
        id: "color-cream",
        nameAr: "كريمي",
        nameEn: "Cream",
        hex: "#e5d8c0",
        imageUrl: "https://images.unsplash.com/photo-1520975954732-35dd22299614?auto=format&fit=crop&w=1200&q=82",
        isAvailable: true,
        sortOrder: 1,
        variants: [
          { id: "v-cream-m", colorId: "color-cream", size: "M", isAvailable: true },
          { id: "v-cream-l", colorId: "color-cream", size: "L", isAvailable: true },
          { id: "v-cream-xl", colorId: "color-cream", size: "XL", isAvailable: true }
        ]
      }
    ]
  },
  {
    id: "prod-olive",
    categoryId: "cat-tshirts",
    slug: "olive-city-tee",
    internalCode: "WH-TEE-009",
    nameAr: "تي شيرت أوليف",
    nameEn: "Olive City Tee",
    descriptionAr: "تي شيرت بلون زيتوني مطفي، مناسب للتنسيق مع الدنيم والجاكيتات.",
    descriptionEn: "A muted olive tee that works cleanly with denim and light jackets.",
    shortDescriptionAr: "لون زيتوني مطفي وحضور يومي.",
    shortDescriptionEn: "Muted olive tone with everyday presence.",
    price: 175000,
    currency: "SYP",
    status: "visible",
    isFeatured: false,
    category: seedCategories[0],
    images: [
      {
        id: "img-olive",
        url: "https://images.unsplash.com/photo-1529139574466-a303027c1d8b?auto=format&fit=crop&w=1200&q=82",
        altAr: "تي شيرت أوليف",
        altEn: "Olive tee",
        isMain: true,
        colorId: "color-olive",
        sortOrder: 1
      }
    ],
    colors: [
      {
        id: "color-olive",
        nameAr: "زيتوني",
        nameEn: "Olive",
        hex: "#6b6b54",
        imageUrl: "https://images.unsplash.com/photo-1529139574466-a303027c1d8b?auto=format&fit=crop&w=1200&q=82",
        isAvailable: true,
        sortOrder: 1,
        variants: [
          { id: "v-olive-s", colorId: "color-olive", size: "S", isAvailable: true },
          { id: "v-olive-m", colorId: "color-olive", size: "M", isAvailable: true },
          { id: "v-olive-l", colorId: "color-olive", size: "L", isAvailable: true }
        ]
      }
    ]
  },
  {
    id: "prod-jacket",
    categoryId: "cat-jackets",
    slug: "ink-light-jacket",
    internalCode: "WH-JKT-003",
    nameAr: "جاكيت إنك خفيف",
    nameEn: "Ink Light Jacket",
    descriptionAr: "جاكيت خفيف بلون أزرق داكن مع تفاصيل بسيطة للمدينة.",
    descriptionEn: "A lightweight dark blue jacket with clean city details.",
    shortDescriptionAr: "جاكيت خفيف بتفاصيل مدينة.",
    shortDescriptionEn: "Light jacket with city-ready details.",
    price: 420000,
    currency: "SYP",
    status: "visible",
    isFeatured: true,
    category: seedCategories[2],
    images: [
      {
        id: "img-jacket",
        url: "https://images.unsplash.com/photo-1551028719-00167b16eac5?auto=format&fit=crop&w=1200&q=82",
        altAr: "جاكيت إنك",
        altEn: "Ink jacket",
        isMain: true,
        colorId: "color-ink",
        sortOrder: 1
      }
    ],
    colors: [
      {
        id: "color-ink",
        nameAr: "أزرق داكن",
        nameEn: "Ink",
        hex: "#1f3145",
        imageUrl: "https://images.unsplash.com/photo-1551028719-00167b16eac5?auto=format&fit=crop&w=1200&q=82",
        isAvailable: true,
        sortOrder: 1,
        variants: [
          { id: "v-ink-m", colorId: "color-ink", size: "M", isAvailable: true },
          { id: "v-ink-l", colorId: "color-ink", size: "L", isAvailable: true },
          { id: "v-ink-xl", colorId: "color-ink", size: "XL", isAvailable: true }
        ]
      }
    ]
  }
];
