import { notFound } from "next/navigation";
import { Footer } from "@/components/Footer";
import { Header } from "@/components/Header";
import { ProductDetailsClient } from "@/components/ProductDetailsClient";
import { getProductBySlug, getStoreSettings, getVisibleCategories } from "@/lib/data";

export default async function Page({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const [product, categories, settings] = await Promise.all([
    getProductBySlug(slug),
    getVisibleCategories(),
    getStoreSettings()
  ]);
  if (!product) notFound();
  return (
    <div className="page-shell" dir="rtl" lang="ar">
      <Header locale="ar" />
      <main className="px-4 py-10 md:px-12 lg:px-20 lg:py-16">
        <ProductDetailsClient product={product} locale="ar" />
      </main>
      <Footer locale="ar" categories={categories} settings={settings} />
    </div>
  );
}
