import Image from "next/image";
import Link from "next/link";
import { Footer } from "./Footer";
import { Header } from "./Header";
import { ProductCard } from "./ProductCard";
import { dictionary, localPath, textByLocale } from "@/lib/i18n";
import type { CategoryView, Locale, ProductView, StoreSettingsView } from "@/lib/types";

const heroImage =
  "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=1400&q=82";

export function HomePage({
  locale,
  categories,
  products,
  settings
}: {
  locale: Locale;
  categories: CategoryView[];
  products: ProductView[];
  settings: StoreSettingsView;
}) {
  const t = dictionary[locale];

  return (
    <div className="page-shell" dir={t.dir} lang={locale}>
      <Header locale={locale} />
      <main>
        <section className="relative grid min-h-[calc(100svh-4.5rem)] overflow-hidden lg:grid-cols-[1.08fr_0.92fr]">
          <div className="relative z-10 flex min-w-0 flex-col justify-center px-4 py-14 sm:px-6 md:px-10 lg:px-16 xl:px-20">
            <p className="mb-5 max-w-full text-[0.72rem] font-black uppercase tracking-[0.18em] text-caramel sm:mb-7">
              {t.heroTop}
            </p>
            <h1 className="display-tight max-w-[14ch] text-[clamp(3.25rem,13vw,9rem)] text-ink sm:max-w-[12ch]">
              <span className="block">{t.heroBlack}</span>
              <span className="block text-caramel">{t.heroWhite}</span>
            </h1>
            <p className="mt-6 max-w-xl text-base font-semibold leading-8 text-muted sm:text-lg">
              {t.heroSub}
            </p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:flex-wrap">
              <Link
                href={localPath(locale, "/products")}
                className="tap-target inline-flex items-center justify-center rounded-full bg-ink px-6 py-3 text-sm font-black uppercase text-bone transition hover:bg-caramel"
              >
                {t.heroCta}
              </Link>
              <Link
                href={localPath(locale, "/#categories")}
                className="tap-target inline-flex items-center justify-center rounded-full border border-ink/15 bg-paper/75 px-6 py-3 text-sm font-black uppercase text-ink transition hover:border-caramel"
              >
                {t.secondaryCta}
              </Link>
            </div>
          </div>
          <div className="relative min-h-[22rem] bg-stonewash sm:min-h-[30rem] lg:min-h-0">
            <Image src={heroImage} alt="White House editorial menswear" fill priority className="object-cover object-center" />
            <div className="absolute inset-0 bg-gradient-to-t from-ink/35 via-transparent to-paper/10 lg:bg-ink/10" />
          </div>
        </section>

        <section id="categories" className="px-4 py-12 sm:px-6 md:px-10 lg:px-16 lg:py-18 xl:px-20">
          <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
            <h2 className="display-tight text-[clamp(2.8rem,8vw,6.5rem)] text-ink">{t.categories}</h2>
            <Link className="arrow-link w-fit" href={localPath(locale, "/products")}>
              {t.viewAll}
            </Link>
          </div>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {categories.map((category) => (
              <Link
                key={category.id}
                href={localPath(locale, `/products?category=${category.slug}`)}
                className="group relative min-h-[16rem] overflow-hidden rounded-2xl bg-ink text-bone shadow-[0_18px_50px_rgb(23_22_60/0.14)]"
              >
                <Image
                  src={category.imageUrl || "/brand/shirt-stone.png"}
                  alt={textByLocale(locale, category.nameAr, category.nameEn)}
                  fill
                  sizes="(min-width: 1024px) 33vw, 100vw"
                  className="object-cover transition duration-700 ease-[var(--ease-out)] group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-ink/78 via-ink/18 to-transparent" />
                <div className="absolute inset-x-5 bottom-5">
                  <p className="text-xs font-black uppercase tracking-[0.18em] text-bone/65">{t.viewCategory}</p>
                  <h3 className="mt-2 text-3xl font-black leading-tight text-bone">
                    {textByLocale(locale, category.nameAr, category.nameEn)}
                  </h3>
                </div>
              </Link>
            ))}
          </div>
        </section>

        <section className="px-4 py-14 sm:px-6 md:px-10 lg:px-16 lg:py-20 xl:px-20">
          <div className="grid gap-5 md:grid-cols-[1fr_0.9fr] md:items-end">
            <h2 className="display-tight text-[clamp(3rem,9vw,7.2rem)]">
              <span className="block text-ink">{t.newest}</span>
              <span className="block text-caramel">{t.newestLight}</span>
            </h2>
            <p className="max-w-xl text-base leading-8 text-muted md:text-lg">{t.categoryHint}</p>
          </div>
          <div className="mt-9 grid gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {products.map((product) => (
              <div key={product.id} className="grid gap-3">
                <ProductCard product={product} locale={locale} />
                {product.category && (
                  <Link
                    href={localPath(locale, `/products?category=${product.category.slug}`)}
                    className="arrow-link w-fit text-ink/75"
                  >
                    {textByLocale(locale, product.category.nameAr, product.category.nameEn)}
                  </Link>
                )}
              </div>
            ))}
          </div>
        </section>

        <section className="mx-4 grid gap-7 border-y border-ink/15 py-12 sm:mx-6 md:mx-10 md:grid-cols-[0.75fr_1.25fr] lg:mx-16 lg:py-18 xl:mx-20">
          <h2 className="display-tight text-[clamp(2.8rem,7vw,6rem)]">{t.about}</h2>
          <div className="max-w-3xl">
            <p className="text-2xl font-semibold leading-tight md:text-4xl">
              {textByLocale(locale, settings.aboutAr, settings.aboutEn)}
            </p>
            <p className="mt-6 text-base leading-8 text-muted md:text-lg">
              {textByLocale(locale, settings.locationAr, settings.locationEn)}
            </p>
          </div>
        </section>
      </main>
      <Footer locale={locale} categories={categories} settings={settings} />
    </div>
  );
}
