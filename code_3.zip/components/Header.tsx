"use client";

import Link from "next/link";
import { useState } from "react";
import { BrandMark } from "./BrandMark";
import { dictionary, localPath } from "@/lib/i18n";
import type { Locale } from "@/lib/types";
import { CartBadge } from "./cart/CartBadge";

export function Header({ locale }: { locale: Locale }) {
  const [open, setOpen] = useState(false);
  const t = dictionary[locale];
  const switchHref = locale === "ar" ? "/en" : "/";
  const links = [
    { href: localPath(locale, "/"), label: t.home },
    { href: localPath(locale, "/#categories"), label: t.categories },
    { href: localPath(locale, "/products"), label: t.products },
    { href: localPath(locale, "/#about"), label: t.about }
  ];

  return (
    <header className="sticky top-0 z-50 border-b border-ink/10 bg-paper/90 shadow-[0_12px_40px_rgb(23_22_60/0.08)] backdrop-blur-xl">
      <div className="mx-auto flex max-w-[118rem] items-center justify-between gap-4 px-4 py-3 md:px-8 lg:px-12 lg:py-4">
        <Link href={localPath(locale, "/")} aria-label="White House home" onClick={() => setOpen(false)}>
          <BrandMark />
        </Link>

        <nav className="hidden items-center gap-7 text-[0.78rem] font-black uppercase text-ink/85 md:flex">
          {links.map((link) => (
            <Link key={link.href} className="transition hover:text-caramel" href={link.href}>
              {link.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-2 sm:gap-3">
          <Link
            className="tap-target rounded-full border border-ink/10 bg-bone px-4 py-2 text-[0.72rem] font-black uppercase text-ink shadow-sm transition hover:border-caramel"
            href={switchHref}
            onClick={() => setOpen(false)}
          >
            {t.language}
          </Link>
          <CartBadge />
          <button
            className="tap-target rounded-full border border-ink/10 bg-ink px-4 py-2 text-[0.72rem] font-black uppercase text-bone md:hidden"
            type="button"
            aria-expanded={open}
            onClick={() => setOpen((value) => !value)}
          >
            {open ? t.close : t.menu}
          </button>
        </div>
      </div>

      {open && (
        <nav className="border-t border-ink/10 bg-paper px-4 pb-4 pt-2 shadow-[0_24px_60px_rgb(23_22_60/0.12)] md:hidden">
          <div className="grid gap-2">
            {links.map((link) => (
              <Link
                key={link.href}
                className="rounded-2xl bg-bone px-4 py-4 text-sm font-black uppercase"
                href={link.href}
                onClick={() => setOpen(false)}
              >
                {link.label}
              </Link>
            ))}
          </div>
        </nav>
      )}
    </header>
  );
}
