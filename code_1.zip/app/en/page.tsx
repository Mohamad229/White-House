import { HomePage } from "@/components/HomePage";
import { getFeaturedProducts, getStoreSettings, getVisibleCategories } from "@/lib/data";

export default async function Page() {
  const [categories, products, settings] = await Promise.all([
    getVisibleCategories(),
    getFeaturedProducts(4),
    getStoreSettings()
  ]);
  return <HomePage locale="en" categories={categories} products={products} settings={settings} />;
}
