import Image from "next/image";
import Link from "next/link";
import { Footer } from "./Footer";
import { Header } from "./Header";
import { ProductCard } from "./ProductCard";
import { dictionary, localPath, textByLocale } from "@/lib/i18n";
import type { CategoryView, Locale, ProductView, StoreSettingsView } from "@/lib/types";

const heroImage =
  "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=1400&q=82";

export function HomePage({
  locale,
  categories,
  products,
  settings
}: {
  locale: Locale;
  categories: CategoryView[];
  products: ProductView[];
  settings: StoreSettingsView;
}) {
  const t = dictionary[locale];

  return (
    <div className="page-shell" dir={t.dir} lang={locale}>
      <Header locale={locale} />
      <main>
        <section className="relative grid min-h-[calc(100vh-4rem)] overflow-hidden lg:grid-cols-[1.45fr_1fr]">
          <div className="relative z-10 flex flex-col justify-center px-4 py-14 md:px-12 lg:px-20">
            <p className="mb-8 text-[0.72rem] font-black uppercase text-caramel md:mb-10">{t.heroTop}</p>
            <h1 className="display-tight max-w-[70rem] text-[clamp(4.4rem,13vw,12.4rem)]">
              <span className="block text-ink">{locale === "ar" ? "وايت" : "White"}</span>
              <span className="block text-ink">{locale === "ar" ? "هاوس" : "House"}</span>
              <span className="block text-bone">{locale === "ar" ? "للرجل" : "Menswear"}</span>
            </h1>
            <Link href={localPath(locale, "/products")} className="arrow-link mt-10 w-fit md:mt-14">
              {t.heroCta}
            </Link>
            <p className="mt-10 max-w-md text-sm font-semibold leading-7 text-muted md:mt-16">
              {locale === "ar"
                ? "قطع رجالية يومية، صور واضحة، طلب سريع، وتأكيد نهائي عبر واتساب."
                : "Daily men's essentials, clear product views, fast ordering, and final confirmation through WhatsApp."}
            </p>
          </div>
          <div className="relative min-h-[30rem] bg-stonewash lg:min-h-0">
            <Image src={heroImage} alt="White House editorial menswear" fill priority className="object-cover object-center" />
            <div className="absolute inset-0 bg-ink/10" />
          </div>
          <div className="absolute bottom-8 left-[56%] z-20 hidden h-28 w-28 bg-brass/70 lg:block" />
        </section>

        <section id="categories" className="px-3 py-10 md:px-5 lg:py-16">
          <div className="mb-5 flex items-end justify-between px-1 md:px-0">
            <h2 className="display-tight text-5xl text-ink md:text-8xl">{t.categories}</h2>
            <Link className="arrow-link" href={localPath(locale, "/products")}>
              {t.viewAll}
            </Link>
          </div>
          <div className="grid gap-2 md:grid-cols-3 lg:grid-cols-5">
            {categories.map((category) => (
              <Link
                key={category.id}
                href={localPath(locale, `/products?category=${category.slug}`)}
                className="group relative min-h-[14rem] overflow-hidden rounded-[2px] bg-ink text-bone md:min-h-[34rem]"
              >
                <Image
                  src={category.imageUrl || "/brand/shirt-stone.png"}
                  alt={textByLocale(locale, category.nameAr, category.nameEn)}
                  fill
                  className="object-cover grayscale transition duration-700 ease-[var(--ease-out)] group-hover:scale-105 group-hover:grayscale-0"
                />
                <div className="absolute inset-0 bg-ink/38 transition group-hover:bg-ink/20" />
                <div className="absolute inset-x-4 bottom-4 md:bottom-6">
                  <h3 className="text-4xl font-black leading-none text-bone/85 md:[writing-mode:vertical-rl] md:text-6xl">
                    {textByLocale(locale, category.nameAr, category.nameEn)}
                  </h3>
                </div>
              </Link>
            ))}
          </div>
        </section>

        <section className="px-4 py-16 md:px-12 lg:px-20 lg:py-24">
          <div className="grid gap-8 md:grid-cols-[1.2fr_0.8fr] md:items-end">
            <h2 className="display-tight text-[clamp(4.5rem,13vw,10.5rem)]">
              <span className="block text-ink">{t.newest}</span>
              <span className="block text-bone">{t.newestLight}</span>
            </h2>
            <p className="max-w-xl text-lg leading-8 text-muted">
              {locale === "ar"
                ? "اختيارات جديدة بتوازن بين البساطة والحضور، مصممة لطلب سريع وواضح."
                : "Fresh pieces with a balance of restraint and presence, designed for a fast WhatsApp order flow."}
            </p>
          </div>
          <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {products.map((product) => (
              <ProductCard key={product.id} product={product} locale={locale} />
            ))}
          </div>
        </section>

        <section className="mx-4 grid gap-8 border-y border-ink/15 py-14 md:mx-12 md:grid-cols-[0.85fr_1.15fr] lg:mx-20 lg:py-20">
          <h2 className="display-tight text-5xl md:text-8xl">{t.about}</h2>
          <div className="max-w-3xl">
            <p className="text-3xl font-semibold leading-tight md:text-5xl">
              {textByLocale(locale, settings.aboutAr, settings.aboutEn)}
            </p>
            <p className="mt-6 text-lg leading-8 text-muted">{textByLocale(locale, settings.locationAr, settings.locationEn)}</p>
          </div>
        </section>
      </main>
      <Footer locale={locale} categories={categories} settings={settings} />
    </div>
  );
}
