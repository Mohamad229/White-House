"use client";

import { useState } from "react";
import type { CategoryView, ProductView } from "@/lib/types";

export function ProductForm({ product, categories }: { product?: ProductView | null; categories: CategoryView[] }) {
  const [status, setStatus] = useState("");

  const initialImagesJson =
    product?.images && product.images.length
      ? JSON.stringify(
          product.images.map(({ url, altAr, altEn, isMain, colorId, sortOrder }) => ({
            url,
            altAr,
            altEn,
            isMain,
            colorId,
            sortOrder
          })),
          null,
          2
        )
      : JSON.stringify(
          [
            {
              url: "https://images.unsplash.com/photo-1523398002811-999ca8dec234?auto=format&fit=crop&w=1200&q=82",
              altAr: "صورة المنتج",
              altEn: "Product image",
              isMain: true,
              colorId: "stone",
              sortOrder: 1
            }
          ],
          null,
          2
        );

  const initialColorsJson =
    product?.colors && product.colors.length
      ? JSON.stringify(
          product.colors.map(({ id, nameAr, nameEn, hex, imageUrl, isAvailable, sortOrder, variants }) => ({
            id,
            nameAr,
            nameEn,
            hex,
            imageUrl,
            isAvailable,
            sortOrder,
            sizes: variants.map((variant) => variant.size)
          })),
          null,
          2
        )
      : JSON.stringify(
          [
            {
              id: "stone",
              nameAr: "ستون",
              nameEn: "Stone",
              hex: "#eee9dd",
              imageUrl: "https://images.unsplash.com/photo-1523398002811-999ca8dec234?auto=format&fit=crop&w=1200&q=82",
              isAvailable: true,
              sortOrder: 1,
              sizes: ["S", "M", "L"]
            }
          ],
          null,
          2
        );

  const [imagesJson, setImagesJson] = useState(initialImagesJson);
  const [colorsJson, setColorsJson] = useState(initialColorsJson);

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setStatus("");
    const form = new FormData(event.currentTarget);
    const body = Object.fromEntries(form.entries());
    const response = await fetch(product ? `/api/admin/products/${product.id}` : "/api/admin/products", {
      method: product ? "PUT" : "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        ...body,
        price: Number(body.price || 0),
        isFeatured: form.get("isFeatured") === "on",
        imagesJson,
        colorsJson
      })
    });

    const data = await response.json().catch(() => null);
    if (!response.ok) {
      setStatus(data?.error || "تعذر حفظ المنتج. راجع الحقول وقاعدة البيانات.");
      return;
    }
    setStatus(`تم حفظ المنتج. الرابط المستخدم: ${data.slug || body.slug}`);
  }

  async function uploadImage(event: React.ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;
    const form = new FormData();
    form.append("file", file);
    const response = await fetch("/api/admin/uploads", { method: "POST", body: form });
    const data = await response.json();
    if (!response.ok) {
      setStatus(data.error || "تعذر رفع الصورة.");
      return;
    }

    let current: any[] = [];
    try {
      current = JSON.parse(imagesJson || "[]");
    } catch {
      current = [];
    }

    current.push({
      url: data.url,
      altAr: product?.nameAr || "صورة المنتج",
      altEn: product?.nameEn || "Product image",
      isMain: current.length === 0,
      colorId: null,
      sortOrder: current.length + 1
    });
    setImagesJson(JSON.stringify(current, null, 2));
    setStatus("تم رفع الصورة وإضافتها إلى قائمة الصور.");
  }

  return (
    <form onSubmit={submit} className="grid gap-5 bg-bone p-5">
      <div className="grid gap-4 md:grid-cols-2">
        <Field name="nameAr" label="الاسم العربي" defaultValue={product?.nameAr} required />
        <Field name="nameEn" label="الاسم الإنجليزي" defaultValue={product?.nameEn} required />
        <Field name="slug" label="الرابط المختصر، سيتم تعديله تلقائيا إذا كان مستخدما" defaultValue={product?.slug} />
        <Field name="internalCode" label="كود داخلي للموظفين" defaultValue={product?.internalCode} required />
        <label className="block">
          <span className="mb-2 block text-sm font-black">القسم</span>
          <select className="admin-field" name="categoryId" defaultValue={product?.categoryId || categories[0]?.id}>
            {categories.map((category) => (
              <option key={category.id} value={category.id}>
                {category.nameAr} / {category.nameEn}
              </option>
            ))}
          </select>
        </label>
        <Field name="price" label="السعر SYP" type="number" defaultValue={String(product?.price ?? 0)} required />
        <label className="block">
          <span className="mb-2 block text-sm font-black">الحالة</span>
          <select className="admin-field" name="status" defaultValue={product?.status || "visible"}>
            <option value="visible">ظاهر ومتاح</option>
            <option value="hidden">مخفي</option>
            <option value="outOfStock">غير متوفر</option>
          </select>
        </label>
        <Field name="currency" label="العملة" defaultValue={product?.currency || "SYP"} />
      </div>

      <Textarea name="shortDescriptionAr" label="وصف قصير عربي" defaultValue={product?.shortDescriptionAr} />
      <Textarea name="shortDescriptionEn" label="وصف قصير إنجليزي" defaultValue={product?.shortDescriptionEn} />
      <Textarea name="descriptionAr" label="وصف كامل عربي" defaultValue={product?.descriptionAr} />
      <Textarea name="descriptionEn" label="وصف كامل إنجليزي" defaultValue={product?.descriptionEn} />

      <label className="block bg-paper p-4">
        <span className="mb-2 block text-sm font-black">رفع صورة محلية</span>
        <input type="file" accept="image/png,image/jpeg,image/webp,image/gif" onChange={uploadImage} />
      </label>

      <div className="grid gap-4 lg:grid-cols-2">
        <Textarea name="imagesJson" label="صور المنتج JSON" value={imagesJson} onChange={(event) => setImagesJson(event.target.value)} />
        <Textarea name="colorsJson" label="الألوان والمقاسات JSON" value={colorsJson} onChange={(event) => setColorsJson(event.target.value)} />
      </div>

      <label className="flex items-center gap-2 font-black">
        <input type="checkbox" name="isFeatured" defaultChecked={product?.isFeatured ?? false} />
        يظهر ضمن أحدث المنتجات
      </label>
      <button className="w-fit bg-ink px-6 py-3 font-black text-bone">حفظ المنتج</button>
      {status && <p className="font-bold text-caramel">{status}</p>}
    </form>
  );
}

function Field({ label, ...props }: React.InputHTMLAttributes<HTMLInputElement> & { label: string }) {
  return (
    <label className="block">
      <span className="mb-2 block text-sm font-black">{label}</span>
      <input className="admin-field" {...props} />
    </label>
  );
}

function Textarea({ label, ...props }: React.TextareaHTMLAttributes<HTMLTextAreaElement> & { label: string }) {
  return (
    <label className="block">
      <span className="mb-2 block text-sm font-black">{label}</span>
      <textarea className="admin-field min-h-36 font-mono text-sm" {...props} />
    </label>
  );
}
