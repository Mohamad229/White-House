import Link from "next/link";
import { AdminHeader, AdminShell } from "@/components/admin/AdminShell";
import { requireAdmin } from "@/lib/auth";
import { getAdminProducts } from "@/lib/data";
import { formatMoney } from "@/lib/format";

export default async function Page() {
  await requireAdmin();
  const products = await getAdminProducts();
  return (
    <AdminShell>
      <AdminHeader
        title="المنتجات"
        action={<Link className="bg-ink px-5 py-3 font-black text-bone" href="/admin/products/new">منتج جديد</Link>}
      />
      <div className="overflow-x-auto bg-bone">
        <table className="w-full min-w-[760px] text-right">
          <thead className="bg-ink text-bone">
            <tr>
              <th className="p-3">المنتج</th>
              <th className="p-3">الكود</th>
              <th className="p-3">القسم</th>
              <th className="p-3">السعر</th>
              <th className="p-3">الحالة</th>
              <th className="p-3">تعديل</th>
            </tr>
          </thead>
          <tbody>
            {products.map((product: any) => (
              <tr key={product.id} className="border-b border-ink/10">
                <td className="p-3 font-black">{product.nameAr}</td>
                <td className="p-3">{product.internalCode}</td>
                <td className="p-3">{product.category?.nameAr}</td>
                <td className="p-3">{formatMoney(product.price, product.currency, "ar")}</td>
                <td className="p-3">{product.status}</td>
                <td className="p-3">
                  <Link className="font-black text-caramel" href={`/admin/products/${product.id}`}>فتح</Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </AdminShell>
  );
}
