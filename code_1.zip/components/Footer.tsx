import Image from "next/image";
import Link from "next/link";
import { BrandMark } from "./BrandMark";
import { dictionary, localPath, textByLocale } from "@/lib/i18n";
import type { CategoryView, Locale, StoreSettingsView } from "@/lib/types";

const footerImage =
  "https://images.unsplash.com/photo-1489987707025-afc232f7ea0f?auto=format&fit=crop&w=1400&q=82";

export function Footer({
  locale,
  categories,
  settings
}: {
  locale: Locale;
  categories: CategoryView[];
  settings: StoreSettingsView;
}) {
  const t = dictionary[locale];

  return (
    <footer id="about" className="mt-20 overflow-hidden bg-ink text-bone">
      <div className="-mx-8 rotate-2 overflow-hidden bg-bone py-3 text-ink">
        <div className="flex min-w-max animate-[marquee_26s_linear_infinite] gap-8 text-4xl font-black uppercase tracking-normal md:text-6xl">
          {Array.from({ length: 10 }).map((_, index) => (
            <span key={index}>White House</span>
          ))}
        </div>
      </div>

      <div className="grid min-h-[34rem] md:grid-cols-[0.9fr_1.1fr]">
        <div className="relative min-h-[22rem]">
          <Image src={footerImage} alt="Menswear rails inside White House" fill className="object-cover opacity-55" />
          <div className="absolute inset-0 bg-ink/50" />
          <div className="absolute inset-x-6 bottom-8 max-w-sm">
            <BrandMark inverse />
            <p className="mt-8 text-4xl leading-tight">{textByLocale(locale, settings.aboutAr, settings.aboutEn)}</p>
          </div>
        </div>

        <div className="grid gap-10 px-6 py-14 md:grid-cols-3 md:px-14 md:py-24">
          <FooterColumn title={t.categories}>
            {categories.map((category) => (
              <Link key={category.id} href={localPath(locale, `/products?category=${category.slug}`)}>
                {textByLocale(locale, category.nameAr, category.nameEn)}
              </Link>
            ))}
          </FooterColumn>
          <FooterColumn title={t.support}>
            <a href={`mailto:${settings.supportEmail}`}>{settings.supportEmail}</a>
            <a href={`https://wa.me/${settings.whatsappNumber.replace(/[^\d]/g, "")}`}>WhatsApp</a>
            {settings.supportPhone && <span>{settings.supportPhone}</span>}
            <span>{textByLocale(locale, settings.locationAr, settings.locationEn)}</span>
          </FooterColumn>
          <FooterColumn title={t.social}>
            {settings.facebookUrl && <a href={settings.facebookUrl}>Facebook</a>}
            {settings.instagramUrl && <a href={settings.instagramUrl}>Instagram</a>}
            {settings.whatsappUrl && <a href={settings.whatsappUrl}>WhatsApp</a>}
          </FooterColumn>
        </div>
      </div>
      <style>{`
        @keyframes marquee {
          from { transform: translateX(0); }
          to { transform: translateX(-50%); }
        }
      `}</style>
    </footer>
  );
}

function FooterColumn({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <h3 className="mb-6 text-sm font-black uppercase text-bone">{title}</h3>
      <div className="grid gap-3 text-base leading-7 text-bone/55">{children}</div>
    </div>
  );
}
