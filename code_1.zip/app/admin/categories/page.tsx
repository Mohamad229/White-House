import { AdminHeader, AdminShell } from "@/components/admin/AdminShell";
import { CategoryForm } from "@/components/admin/CategoryForm";
import { requireAdmin } from "@/lib/auth";
import { getAllCategories } from "@/lib/data";

export default async function Page() {
  await requireAdmin();
  const categories = await getAllCategories();
  return (
    <AdminShell>
      <AdminHeader title="الأقسام" />
      <div className="grid gap-6 lg:grid-cols-[1fr_1fr]">
        <CategoryForm />
        <div className="space-y-3">
          {categories.map((category) => (
            <div key={category.id} className="bg-bone p-4">
              <h2 className="text-xl font-black">{category.nameAr} / {category.nameEn}</h2>
              <p className="mt-1 text-sm text-muted">{category.slug}</p>
              <div className="mt-4">
                <CategoryForm category={category} />
              </div>
            </div>
          ))}
        </div>
      </div>
    </AdminShell>
  );
}
