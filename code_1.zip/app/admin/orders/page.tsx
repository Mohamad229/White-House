import Link from "next/link";
import { AdminHeader, AdminShell } from "@/components/admin/AdminShell";
import { requireAdmin } from "@/lib/auth";
import { getAdminOrders } from "@/lib/data";
import { formatMoney } from "@/lib/format";

export default async function Page() {
  await requireAdmin();
  const orders = await getAdminOrders();
  return (
    <AdminShell>
      <AdminHeader title="الطلبات" />
      <div className="grid gap-3">
        {orders.map((order: any) => (
          <Link key={order.id} href={`/admin/orders/${order.id}`} className="grid gap-2 bg-bone p-4 md:grid-cols-5">
            <strong>{order.code}</strong>
            <span>{order.customerName}</span>
            <span>{order.customerPhone}</span>
            <span>{order.status}</span>
            <span>{formatMoney(order.total, order.currency, "ar")}</span>
          </Link>
        ))}
        {orders.length === 0 && <p className="bg-bone p-5 text-muted">لا توجد طلبات بعد.</p>}
      </div>
    </AdminShell>
  );
}
