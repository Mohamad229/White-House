import type { Locale } from "./types";

export const dictionary = {
  ar: {
    dir: "rtl",
    home: "الرئيسية",
    categories: "الأقسام",
    products: "المنتجات",
    about: "عن المتجر",
    language: "English",
    heroTop: "ملابس رجالية",
    heroBlack: "مختارة",
    heroWhite: "بثقة هادئة",
    heroCta: "تسوق المجموعة",
    newest: "أحدث",
    newestLight: "المنتجات",
    viewAll: "عرض الكل",
    addToOrder: "أضف للطلب",
    details: "التفاصيل",
    filters: "تصفية الأقسام",
    all: "الكل",
    size: "المقاس",
    color: "اللون",
    quantity: "الكمية",
    aboutProduct: "عن المنتج",
    orderBar: "طلبك",
    review: "مراجعة الطلب",
    checkout: "إكمال الطلب",
    total: "الإجمالي",
    empty: "لا توجد منتجات متاحة حاليا.",
    name: "الاسم الكامل",
    phone: "رقم الهاتف",
    cityArea: "المدينة والمنطقة",
    address: "العنوان التفصيلي",
    notes: "ملاحظات اختيارية",
    submitOrder: "حفظ الطلب وفتح واتساب",
    continueShopping: "متابعة التسوق",
    remove: "حذف",
    support: "الدعم",
    social: "روابط التواصل"
  },
  en: {
    dir: "ltr",
    home: "Home",
    categories: "Categories",
    products: "Products",
    about: "About",
    language: "العربية",
    heroTop: "Men's essentials",
    heroBlack: "shaped",
    heroWhite: "with quiet confidence",
    heroCta: "Shop the edit",
    newest: "Newest",
    newestLight: "products",
    viewAll: "View all",
    addToOrder: "Add to order",
    details: "Details",
    filters: "Category filters",
    all: "All",
    size: "Size",
    color: "Color",
    quantity: "Quantity",
    aboutProduct: "About the product",
    orderBar: "Your order",
    review: "Review order",
    checkout: "Checkout",
    total: "Total",
    empty: "No available products right now.",
    name: "Full name",
    phone: "Phone number",
    cityArea: "City and area",
    address: "Detailed address",
    notes: "Optional notes",
    submitOrder: "Save order and open WhatsApp",
    continueShopping: "Continue shopping",
    remove: "Remove",
    support: "Support",
    social: "Social"
  }
} as const;

export function textByLocale(locale: Locale, ar: string, en: string) {
  return locale === "ar" ? ar : en;
}

export function localPath(locale: Locale, path: string) {
  if (locale === "ar") return path || "/";
  if (!path || path === "/") return "/en";
  return `/en${path}`;
}
