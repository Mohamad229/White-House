import Image from "next/image";
import { AdminHeader, AdminShell } from "@/components/admin/AdminShell";
import { CategoryForm } from "@/components/admin/CategoryForm";
import { requireAdmin } from "@/lib/auth";
import { getAllCategories } from "@/lib/data";

export default async function Page() {
  await requireAdmin();
  const categories = await getAllCategories();
  return (
    <AdminShell>
      <AdminHeader title="الأقسام" />
      <div className="grid gap-6 xl:grid-cols-[0.9fr_1.1fr]">
        <section>
          <div className="mb-4">
            <h2 className="text-2xl font-black">إضافة قسم</h2>
            <p className="mt-1 text-sm text-muted">أضف الاسم والصورة وسيتم إنشاء الرابط المختصر تلقائيا.</p>
          </div>
          <CategoryForm />
        </section>

        <section>
          <h2 className="mb-4 text-2xl font-black">الأقسام الحالية</h2>
          <div className="grid gap-4">
            {categories.map((category) => (
              <details key={category.id} className="premium-card overflow-hidden">
                <summary className="grid cursor-pointer gap-4 p-4 sm:grid-cols-[6rem_1fr_auto] sm:items-center">
                  <div className="relative aspect-square overflow-hidden rounded-2xl bg-bone">
                    {category.imageUrl ? (
                      <Image src={category.imageUrl} alt={category.nameAr} fill className="object-cover" />
                    ) : (
                      <div className="grid h-full place-items-center text-xs text-muted">بدون صورة</div>
                    )}
                  </div>
                  <div>
                    <h3 className="text-xl font-black">{category.nameAr} / {category.nameEn}</h3>
                    <p className="mt-1 text-sm text-muted">{category.slug}</p>
                  </div>
                  <span className={`w-fit rounded-full px-3 py-2 text-xs font-black ${category.isVisible ? "bg-ink text-bone" : "bg-bone text-muted"}`}>
                    {category.isVisible ? "ظاهر" : "مخفي"}
                  </span>
                </summary>
                <div className="border-t border-ink/10 p-4">
                  <CategoryForm category={category} compact />
                </div>
              </details>
            ))}
          </div>
        </section>
      </div>
    </AdminShell>
  );
}
