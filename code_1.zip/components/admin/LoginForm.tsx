"use client";

import { useState } from "react";

export function LoginForm() {
  const [error, setError] = useState("");

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    const form = new FormData(event.currentTarget);
    const response = await fetch("/api/admin/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        username: String(form.get("username") || ""),
        password: String(form.get("password") || "")
      })
    });
    if (!response.ok) {
      setError("بيانات الدخول غير صحيحة.");
      return;
    }
    window.location.href = "/admin";
  }

  return (
    <form onSubmit={submit} className="mx-auto mt-24 max-w-md bg-bone p-6 shadow-bar">
      <h1 className="text-3xl font-black">دخول الإدارة</h1>
      <p className="mt-2 text-sm text-muted">الحساب مشترك في النسخة الأولى. غيّر كلمة المرور من البيئة أو قاعدة البيانات.</p>
      <label className="mt-6 block">
        <span className="mb-2 block text-sm font-black">اسم المستخدم</span>
        <input className="admin-field" name="username" required defaultValue="admin" />
      </label>
      <label className="mt-4 block">
        <span className="mb-2 block text-sm font-black">كلمة المرور</span>
        <input className="admin-field" name="password" type="password" required />
      </label>
      {error && <p className="mt-4 bg-red-100 p-3 text-sm font-bold text-red-800">{error}</p>}
      <button className="mt-6 w-full bg-ink px-5 py-3 font-black text-bone">دخول</button>
    </form>
  );
}
