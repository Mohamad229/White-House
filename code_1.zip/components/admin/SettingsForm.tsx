"use client";

import { useState } from "react";
import type { StoreSettingsView } from "@/lib/types";

export function SettingsForm({ settings }: { settings: StoreSettingsView }) {
  const [status, setStatus] = useState("");

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const response = await fetch("/api/admin/settings", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(Object.fromEntries(form.entries()))
    });
    setStatus(response.ok ? "تم تحديث الإعدادات." : "تعذر التحديث.");
  }

  return (
    <form onSubmit={submit} className="grid gap-4 bg-bone p-5">
      <div className="grid gap-4 md:grid-cols-2">
        {[
          ["storeNameAr", "اسم المتجر عربي"],
          ["storeNameEn", "اسم المتجر إنجليزي"],
          ["whatsappNumber", "رقم واتساب"],
          ["supportPhone", "هاتف الدعم"],
          ["supportEmail", "إيميل الدعم"],
          ["defaultCurrency", "العملة الافتراضية"],
          ["facebookUrl", "Facebook"],
          ["instagramUrl", "Instagram"],
          ["whatsappUrl", "WhatsApp URL"],
          ["locationAr", "الموقع عربي"],
          ["locationEn", "الموقع إنجليزي"]
        ].map(([name, label]) => (
          <label key={name} className="block">
            <span className="mb-2 block text-sm font-black">{label}</span>
            <input className="admin-field" name={name} defaultValue={(settings as any)[name] || ""} />
          </label>
        ))}
      </div>
      <label>
        <span className="mb-2 block text-sm font-black">نص عن المتجر عربي</span>
        <textarea className="admin-field min-h-28" name="aboutAr" defaultValue={settings.aboutAr} />
      </label>
      <label>
        <span className="mb-2 block text-sm font-black">About English</span>
        <textarea className="admin-field min-h-28" name="aboutEn" defaultValue={settings.aboutEn} />
      </label>
      <button className="w-fit bg-ink px-6 py-3 font-black text-bone">حفظ الإعدادات</button>
      {status && <p className="font-bold text-caramel">{status}</p>}
    </form>
  );
}
