import Link from "next/link";
import { BrandMark } from "./BrandMark";
import { dictionary, localPath } from "@/lib/i18n";
import type { Locale } from "@/lib/types";
import { CartBadge } from "./cart/CartBadge";

export function Header({ locale }: { locale: Locale }) {
  const t = dictionary[locale];
  const switchHref = locale === "ar" ? "/en" : "/";

  return (
    <header className="sticky top-0 z-30 border-b border-ink/10 bg-paper/95">
      <div className="mx-auto flex max-w-[118rem] items-center justify-between px-4 py-3 md:px-8 lg:py-4">
        <Link href={localPath(locale, "/")} aria-label="White House home">
          <BrandMark />
        </Link>
        <nav className="hidden items-center gap-7 text-[0.78rem] font-black uppercase md:flex">
          <Link href={localPath(locale, "/")}>{t.home}</Link>
          <Link href={localPath(locale, "/#categories")}>{t.categories}</Link>
          <Link href={localPath(locale, "/products")}>{t.products}</Link>
          <Link href={localPath(locale, "/#about")}>{t.about}</Link>
        </nav>
        <div className="flex items-center gap-3">
          <Link className="bg-bone px-3 py-2 text-[0.68rem] font-black uppercase shadow-sm" href={switchHref}>
            {t.language}
          </Link>
          <CartBadge />
        </div>
      </div>
    </header>
  );
}
