import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}", "./lib/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        paper: "oklch(0.89 0.008 78)",
        stonewash: "oklch(0.78 0.009 72)",
        ink: "oklch(0.16 0.006 78)",
        muted: "oklch(0.48 0.008 72)",
        bone: "oklch(0.96 0.007 78)",
        caramel: "oklch(0.64 0.105 66)",
        brass: "oklch(0.72 0.095 72)"
      },
      fontFamily: {
        sans: ["var(--font-ui)", "Tahoma", "Segoe UI", "sans-serif"],
        display: ["var(--font-display)", "Arial Black", "Tahoma", "sans-serif"]
      },
      boxShadow: {
        bar: "0 -18px 60px oklch(0.16 0.006 78 / 0.16)"
      }
    }
  },
  plugins: []
};

export default config;
